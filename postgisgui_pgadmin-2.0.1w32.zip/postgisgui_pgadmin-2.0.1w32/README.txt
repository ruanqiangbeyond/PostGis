-- THE SHP2PGSQL-GUI -- 
The shp2pgsql-gui can run standalone or as a plugin under PgAdminIII. To run under a PgAdminIII install,
1) copy the postgis-gui folder to your bin directory which is identified in PgAdminIII -> Options -> General -> PG-binpath
2) 
-- IF you are using PgAdmin III 1.9 - 1.12
overwrite the plugins.ini (assuming you haven't customized it), with the one in here,
or alternatively cut in these lines into your existing PgAdmin III plugins.ini.  This should work for PgAdmin III 1.9+

----Start here --
;
; PostGIS shp2pgsql-gui (Windows):
;
Title=PostGIS Shapefile and DBF loader
Command="$$PGBINDIR\postgisgui\shp2pgsql-gui.exe" -h "$$HOSTNAME" -p $$PORT -U "$$USERNAME" -d "$$DATABASE" -W "$$PASSWORD"
Description=Open a PostGIS ESRI Shapefile or Plain dbf loader console to the current database.
KeyFile=$$PGBINDIR\postgisgui\shp2pgsql-gui.exe
Platform=windows
ServerType=postgresql
Database=Yes
SetPassword=Yes

--- End Here --



-- If you are using the PgAdmin III 1.13 (this is needed for PostgreSQL 9.1+)
Copy the plugin.d folder to your PgAdmin III root.  If you already have a plugins.d just copy the file included
Please refer to article for more details:
http://www.postgresonline.com/journal/archives/180-PgAdmin-III-1.13-change-in-plugin-architecture-and-PostGIS-Plugins.html